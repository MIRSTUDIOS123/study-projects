function how_old_are_you(){
    let age = prompt("Сколько тебе лет?")
    if (age < 18){
        open("/you_aren't_have_18_age.html")
    }
}

how_old_are_you()