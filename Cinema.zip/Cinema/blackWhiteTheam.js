getComputedStyle(--bgc)
var(--bgc) = rgb(255, 0, 0)
