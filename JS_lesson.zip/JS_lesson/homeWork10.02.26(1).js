function getElements (element) {
    const parent = document.getElementsByName("element")
    childs = element.childNotes()
    return childs
}