const paragraph = childNotes("div")
for (let i = 0; i < paragraph.length;i++){
    if (i%2 === 0){
        const newParagraph = document.createElement("p");
        newParagraph.classList.add("paragraph");
        newParagraph.textContent = "изменено"
        myDiv.appendChild(newParagraph)
    }
}