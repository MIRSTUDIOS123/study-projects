from fastapi import APIRouter, status, HTTPException
from products.schemas import ProductSchema
from users.database import products

product = APIRouter()


@product.post("/", status_code=status.HTTP_201_CREATED)
def create_product(product_data: ProductSchema):
    product_id = len(products) + 1
    new_product = ProductSchema(
        name=product_data.name,
        price=product_data.price,
        count=product_data.count,
        id=product_id,
    )
    products.append(new_product)
    raise HTTPException(status_code=status.HTTP_201_CREATED)


@product.get("/", response_model=list[ProductSchema])
def get_product_list(skip: int = 0, limit: int = 10):
    return products[skip : skip + limit]


@product.patch("/{id}")
def sell_product(id):
    for product in products:
        if product.get("id") == id:
            product["admin"] = True
            return {"message": f"The product is sell ,its id:{id}"}
    return {"error": "Product is not found"}, 404
