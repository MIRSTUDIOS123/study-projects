from fastapi import APIRouter, status, HTTPException
from users.schema import CreateUserSchema, PersonSchema, UserResponesSchema
from users.database import db

user = APIRouter()


@user.post("/", status_code=status.HTTP_201_CREATED)
def create_user(user_data: CreateUserSchema):
    for i in db:
        if i.user_name == user_data.user_name:
            return {"message": "Попытка создания аккаунта заблокирована"}
    if user_data.age <= 20:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="You are so young"
        )

    user_id = len(db) + 1
    new_user = PersonSchema(
        id=user_id,
        name=user_data.name,
        user_name=user_data.user_name,
        password=user_data.password,
        age=user_data.age,
        gender=user_data.gender,
    )
    db.append(new_user)
    return {
        "message": "User created",
        "user": UserResponesSchema(**new_user.model_dump()),
    }


@user.get("/", response_model=list[UserResponesSchema])
def get_db(skip: int = 0, limit: int = 10):
    print(1)
    return db[skip : skip + limit]
