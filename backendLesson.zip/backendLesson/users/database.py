from faker import Faker
from users.schema import PersonSchema
from users.my_enum import Gender
import random

fake = Faker()

db = []

products = []

for i in range(1, 101):
    gender = random.choice((Gender.male, Gender.female))

    person = PersonSchema(
        name=fake.name_male() if gender == Gender.male else fake.name_female(),
        password=fake.password(),
        user_name=fake.user_name(),
        age=random.randint(10, 100),
        gender=gender,
        id=i,
    )
    db.append(person)
