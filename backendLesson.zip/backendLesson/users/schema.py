from pydantic import BaseModel
from users.my_enum import Gender


class BaseUserSchema(BaseModel):
    name: str
    user_name: str
    age: int
    gender: Gender


class CreateUserSchema(BaseUserSchema):
    password: str


class PersonSchema(CreateUserSchema):
    id: int


class UserResponesSchema(BaseUserSchema):
    id: int
