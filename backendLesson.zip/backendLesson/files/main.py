import json
import faker

fake = faker.Faker()

# file = open("files/text_file.txt","r",encoding="utf-8")
# print(file.readline())
# print(file.readline())
# file.close()
# print(file.readline())

# class A:
#     a = "Даня"
#     def __str__(self):
#         return self.a
#     def __enter__(self):
#         print("Я вошёл")
#         return self.a
#     def __exit__(self, exc_type, exc, tb):
#         print("Я вышел")

# a = A()
# with a:
#     5/0
#     print("Я внутри сейчас")
# print("Я снаружи")


# with open("files/text_file2.txt","r",encoding="utf-8") as file:
#     print(file.read())

# with open("files/text_file2.txt","w",encoding="utf-8") as file:
#     print(file.write("Hello my name is Danya!"))

# with open("files/text_file2.txt","a") as file:
#     print(file.write("\nПривет меня зовут Даня!"))


# users = [{"name":fake.name(),"city":fake.city()} for i in range(10)]

# name = "Даниил"
# age = 13

# with open("files/file.json","w",encoding="utf-8") as file:
#     file.write(json.dumps(users,ensure_ascii=False,indent=2))

with open("files/file.json", "r", encoding="utf-8") as file:
    file_info = json.loads(file.read())

for data in file_info:
    if data["name"] == "Amanda Ford":
        print(data)
