# file = open("files/text_file.txt")

# print(file.read())

# file2 = open("files/text_file.txt")

# print(file2.read())
# file2.close()

with open("files/text_file.txt", "r", encoding="utf-8") as file:
    print(file.read())
