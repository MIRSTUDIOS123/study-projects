import sqlite3
import faker
import random

fake = faker.Faker()

def create_table():
    with sqlite3.connect("database.db") as conn:
        cursore = conn.cursor()
        cursore.execute("""
        CREATE TABLE IF NOT EXISTS users(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name VARCHAR(50) NOT NULL,
        city VARCHAR(50),
        age INTEGER,
        salary DECIMAL(10,2),
        job_title VARCHAR(30),
        grate VARCHAR(30),
        email VARCHAR(70) UNIQUE,
        is_active BOOLEAN DEFAULT TRUE
        )""")


# как заполнить базу данных:
# INSERT INTO users(name, city, age, salary, job_title, email)
# VALUES ("Даниил","Москва",13,1_000_000,"Генеральный директор","mail3@list.ru"),
# ("Паша","Москва",26,120_000,"Python разработчик Junior","tipoemail2@list.ru")

def insert_data(count):
    with sqlite3.connect("database.db") as db:
        for i in range(count):
            cursore = db.cursor()
            cursore.execute("""
            INSERT INTO users(name, city, age, salary, job_title, grate, email)
            VALUES (?,?,?,?,?,?,?);
            """,(fake.name(),
                fake.city(),
                random.randint(18,65),
                random.randrange(70_000,1_000_000,5_000),
                random.choice(("Python Developer","Designer","Compositor","SMM-manager","Cleaning manager","Backend Developer","accountant","Team lead","Admin","Security super mega menneger","Meneger of enginering")),
                random.choice(("Junior","Middle","Senior")),
                fake.email()))

# create_table()

# insert_data(300)

# name = input("Enter job title: ")
# grate = input("Enter grate: ")
# salary = int(input("Enter salary: "))

# with sqlite3.connect("database.db") as connection:
#     connection.row_factory = sqlite3.Row
#     cursor = connection.cursor()
#     cursor.execute('''
#     SELECT * FROM users WHERE job_title=? AND grate=? AND salary<?;
#     ''',(name,grate,salary))


#начни с оператора in


# users = []
# for i in cursor.fetchall():
#     users.append(dict(i))
# print(*users,sep="\n")
positon = {"backend developer":{"junior":100_000,"middle":218_000,"senior":300_000},
           "python developer":{"junior":150_000,"middle":300_000,"senior":400_000},
           "team lead":{"junior":400_000,"middle":600_000,"strong":600_000,"senior":800_000}}

def find_big_salary(job_title,grate):

    salary = positon[job_title.lower()][grate.lower()]
    with sqlite3.connect("database.db") as connection:
        connection.row_factory = sqlite3.Row
        cursor = connection.cursor()
        cursor.execute('''
        SELECT name, age, salary, email FROM users WHERE job_title=? AND grate=? AND salary>?;
        ''',(job_title,grate,salary))
    return list(map(dict,cursor.fetchall()))


def find_small_salary():
    job_title = input("Введите професию: ")
    grate = input("Введите уровень: ")
    if job_title == "Backend Developer":
        if grate == "Junior":
            with sqlite3.connect("database.db") as connection:
                connection.row_factory = sqlite3.Row
                cursor = connection.cursor()
                cursor.execute('''
                SELECT name, age, salary, email FROM users WHERE job_title=? AND grate=? AND salary<100_000;
                ''',(job_title,grate))
                rows = []
                for i in cursor.fetchall():
                    rows.append(dict(i))
                print(*rows, sep="\n") 

        elif grate == "Middle":
            with sqlite3.connect("database.db") as connection:
                connection.row_factory = sqlite3.Row
                cursor = connection.cursor()
                cursor.execute('''
                SELECT name, age, salary, email FROM users WHERE job_title=? AND grate=? AND salary<218_000;
                ''',(job_title,grate))
                rows = []
                for i in cursor.fetchall():
                    rows.append(dict(i))
                print(*rows, sep="\n") 

        elif grate == "Senior":
            with sqlite3.connect("database.db") as connection:
                connection.row_factory = sqlite3.Row
                cursor = connection.cursor()
                cursor.execute('''
                SELECT name, age, salary, email FROM users WHERE job_title=? AND grate=? AND salary<300_000;
                ''',(job_title,grate))
                rows = []
                for i in cursor.fetchall():
                    rows.append(dict(i))
                print(*rows, sep="\n")  
        elif grate == "*":
            with sqlite3.connect("database.db") as connection:
                connection.row_factory = sqlite3.Row
                cursor = connection.cursor()
                cursor.execute('''
                SELECT name, age, grate, salary, email FROM users WHERE job_title=? AND grate=? AND salary<300_000;
                ''',(job_title,"Senior"))
                print("123")
                rows = []
                for i in cursor.fetchall():
                    rows.append(dict(i))
                print(*rows, sep="\n")
                print("\n") 

            with sqlite3.connect("database.db") as connection:
                connection.row_factory = sqlite3.Row
                cursor = connection.cursor()
                cursor.execute('''
                SELECT name, age, grate, salary, email FROM users WHERE job_title=? AND grate=? AND salary<218_000;
                ''',(job_title,"Middle"))
                rows = []
                for i in cursor.fetchall():
                    rows.append(dict(i))
                print(*rows, sep="\n") 
                print("\n")

            with sqlite3.connect("database.db") as connection:
                connection.row_factory = sqlite3.Row
                cursor = connection.cursor()
                cursor.execute('''
                SELECT name, age, grate, salary, email FROM users WHERE job_title=? AND grate=? AND salary<100_000;
                ''',(job_title,"Junior"))
                rows = []
                for i in cursor.fetchall():
                    rows.append(dict(i))
                print(*rows, sep="\n")           



    if job_title == "Python Developer":
        if grate == "Junior":
            with sqlite3.connect("database.db") as connection:
                connection.row_factory = sqlite3.Row
                cursor = connection.cursor()
                cursor.execute('''
                SELECT name, age, salary, email FROM users WHERE job_title=? AND grate=? AND salary<150_000;
                ''',(job_title,grate))
                rows = []
                for i in cursor.fetchall():
                    rows.append(dict(i))
                print(*rows, sep="\n") 

        elif grate == "Middle":
            with sqlite3.connect("database.db") as connection:
                connection.row_factory = sqlite3.Row
                cursor = connection.cursor()
                cursor.execute('''
                SELECT name, age, salary, email FROM users WHERE job_title=? AND grate=? AND salary<300_000;
                ''',(job_title,grate))
                rows = []
                for i in cursor.fetchall():
                    rows.append(dict(i))
                print(*rows, sep="\n") 

        elif grate == "Senior":
            with sqlite3.connect("database.db") as connection:
                connection.row_factory = sqlite3.Row
                cursor = connection.cursor()
                cursor.execute('''
                SELECT name, age, salary, email FROM users WHERE job_title=? AND grate=? AND salary<400_000;
                ''',(job_title,grate))
                rows = []
                for i in cursor.fetchall():
                    rows.append(dict(i))
                print(*rows, sep="\n")  
        elif grate == "*":
            with sqlite3.connect("database.db") as connection:
                connection.row_factory = sqlite3.Row
                cursor = connection.cursor()
                cursor.execute('''
                SELECT name, age, grate, salary, email FROM users WHERE job_title=? AND grate=? AND salary<400_000;
                ''',(job_title,"Senior"))
                print("123")
                rows = []
                for i in cursor.fetchall():
                    rows.append(dict(i))
                print(*rows, sep="\n")
                print("\n") 

            with sqlite3.connect("database.db") as connection:
                connection.row_factory = sqlite3.Row
                cursor = connection.cursor()
                cursor.execute('''
                SELECT name, age, grate, salary, email FROM users WHERE job_title=? AND grate=? AND salary<300_000;
                ''',(job_title,"Middle"))
                rows = []
                for i in cursor.fetchall():
                    rows.append(dict(i))
                print(*rows, sep="\n") 
                print("\n")

            with sqlite3.connect("database.db") as connection:
                connection.row_factory = sqlite3.Row
                cursor = connection.cursor()
                cursor.execute('''
                SELECT name, age, grate, salary, email FROM users WHERE job_title=? AND grate=? AND salary<150_000;
                ''',(job_title,"Junior"))
                rows = []
                for i in cursor.fetchall():
                    rows.append(dict(i))
                print(*rows, sep="\n")



    elif job_title == "Team lead":
        if grate == "Junior":
            with sqlite3.connect("database.db") as connection:
                connection.row_factory = sqlite3.Row
                cursor = connection.cursor()
                cursor.execute('''
                SELECT name, age, salary, email FROM users WHERE job_title=? AND grate=? AND salary<400_000;
                ''',(job_title,grate))
                rows = []
                for i in cursor.fetchall():
                    rows.append(dict(i))
                print(*rows, sep="\n") 

        elif grate in ("Middle", "Strong"):
            with sqlite3.connect("database.db") as connection:
                connection.row_factory = sqlite3.Row
                cursor = connection.cursor()
                cursor.execute('''
                SELECT name, age, salary, email FROM users WHERE job_title=? AND grate=? AND salary<600_000;
                ''',(job_title,grate))
                rows = []
                for i in cursor.fetchall():
                    rows.append(dict(i))
                print(*rows, sep="\n") 

        elif grate in ("Senior", "Engineering Manager", "Head of Teams"):
            with sqlite3.connect("database.db") as connection:
                connection.row_factory = sqlite3.Row
                cursor = connection.cursor()
                cursor.execute('''
                SELECT name, age, salary, email FROM users WHERE job_title=? AND grate=? AND salary<800_000;
                ''',(job_title,grate))
                rows = []
                for i in cursor.fetchall():
                    rows.append(dict(i))
                print(*rows, sep="\n")  
        elif grate == "*":
            with sqlite3.connect("database.db") as connection:
                connection.row_factory = sqlite3.Row
                cursor = connection.cursor()
                cursor.execute('''
                SELECT name, age, grate, salary, email FROM users WHERE job_title=? AND grate=? AND salary<400_000;
                ''',(job_title,"Senior"))
                print("123")
                rows = []
                for i in cursor.fetchall():
                    rows.append(dict(i))
                print(*rows, sep="\n")
                print("\n") 

            with sqlite3.connect("database.db") as connection:
                connection.row_factory = sqlite3.Row
                cursor = connection.cursor()
                cursor.execute('''
                SELECT name, age, grate, salary, email FROM users WHERE job_title=? AND grate=? AND salary<600_000;
                ''',(job_title,"Middle"))
                rows = []
                for i in cursor.fetchall():
                    rows.append(dict(i))
                print(*rows, sep="\n") 
                print("\n")

            with sqlite3.connect("database.db") as connection:
                connection.row_factory = sqlite3.Row
                cursor = connection.cursor()
                cursor.execute('''
                SELECT name, age, grate, salary, email FROM users WHERE job_title=? AND grate=? AND salary<400_000;
                ''',(job_title,"Junior"))
                rows = []
                for i in cursor.fetchall():
                    rows.append(dict(i))
                print(*rows, sep="\n")


