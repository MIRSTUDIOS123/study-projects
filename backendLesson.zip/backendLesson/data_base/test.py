import sqlite3

with sqlite3.connect("testdb.db") as db:
    cursor = db.cursor()
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS test_tabel(
    name VARCHAR(50),
    sure_name VARCHAR(50)
    )''')

a = "Даниил"
b = "Демидов"

with sqlite3.connect("testdb.db") as db:
    cursor = db.cursor()
    cursor.execute('''
    INSERT INTO test_tabel(name,sure_name)
    VALUES(?,?)
    ''',(a,b))

