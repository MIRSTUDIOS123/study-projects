from fastapi import FastAPI
from products.view import product
from users.view import user

app = FastAPI()

app.include_router(product, tags=["Product"], prefix="/product")
app.include_router(user, tags=["User"], prefix="/user")
