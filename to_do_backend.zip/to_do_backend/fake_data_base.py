fakeDB = [
    {"id":1, "task":"Привет", "status":True},
    {"id":2, "task":"Подготовиться к ВПР", "status":False},
]